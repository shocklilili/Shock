from create_data import create_new_data
from load_data import read_data, x_y_split
from ml_model import model_select, rf_model
from nn_model import nn_model, nn_train_test
import numpy as np
np.random.seed(123)  
import pandas as pd

test = pd.read_csv("data/test_data.csv")
x_test, y_test = x_y_split(test)

for times in range(1, 6):
    train = create_new_data(20000)
    x_train, y_train = x_y_split(train)
    accuracy_nn, pred_label_nn, pred_proba_nn = nn_train_test(
        x_train, y_train, x_test, y_test)

    test['pred_label_' + str(times)] = pred_label_nn
    test['pred_proba_' + str(times)] = pred_proba_nn


error_predict = list()
for t in test.values:
    label = t[4]
    pred_pabel = [t[5], t[7], t[9], t[11], t[13]]

    count = 0
    for pred in pred_pabel:
        if label != pred:
            count += 1
    if count >=3:
        error_predict.append(True)        
    else:
        error_predict.append(False)

error_df = test[error_predict]
print(error_df)
error_df.to_csv('data/error_predict.csv', index=False)

