import pandas as pd
from sklearn.model_selection import train_test_split

def read_data(data_name):
    # 读取数据
    data = pd.read_csv(data_name)
    y = data['label']
    X = data.drop(columns=['label'])
    x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    return x_train, x_test, y_train, y_test

def x_y_split(data):
    y = data['label']
    x = data.drop(columns = ['label'])
    return x, y