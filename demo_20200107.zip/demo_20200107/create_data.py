import numpy as np
import pandas as pd

def create_new_data(number=20000):
    rand_nps = []
    for k in range(number):
        # create matrix container
        arr = [0] * 5
        rand_np = np.random.randint(-100, 100, (2, 2))
        for i in range(2):
            for j in range(2):
                # print("i = {} and j={}".format(i, j))
                index = i * 2 + j
                # print(index)
                arr[index] = rand_np[i][j]
        eigenvl, _ = np.linalg.eig(rand_np)
        s = 0
        for e in eigenvl:
            if e > 0:
                s += 1
        arr[-1] = 1 if s > 0 else 0

        rand_nps.append(arr)

    nps = np.array(rand_nps).reshape(number, -1)

    data = pd.DataFrame(nps, columns=['a', 'b', 'c', 'd', 'label'])
    df = data.drop_duplicates()
    return df


