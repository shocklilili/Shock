
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')
from load_data import read_data

def model_select(x_train, y_train, x_test, y_test):
    
    clf_lr = LogisticRegression()
    clf_svm = SVC()
    clf_rf = RandomForestClassifier()

    clf_lr.fit(x_train, y_train)
    clf_svm.fit(x_train, y_train)
    clf_rf.fit(x_train, y_train)

    pred_lr = clf_lr.predict(x_test)
    pred_svm = clf_svm.predict(x_test)
    pred_rf = clf_rf.predict(x_test)

    accuracy_lr = accuracy_score(pred_lr, y_test)
    accuracy_svm = accuracy_score(pred_svm, y_test)
    accuracy_rf = accuracy_score(pred_rf, y_test)

    return accuracy_lr, accuracy_svm, accuracy_rf

def rf_model(x_train, y_train, x_test, y_test):
    clf_rf = RandomForestClassifier()
    clf_rf.fit(x_train, y_train)
    pred_rf = clf_rf.predict(x_test)
    accuracy_rf = accuracy_score(pred_rf, y_test)
    return pred_rf, accuracy_rf