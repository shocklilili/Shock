from create_data import create_new_data
from load_data import read_data, x_y_split
from ml_model import model_select, rf_model
from nn_model import nn_model, nn_train_test
import numpy as np

import pandas as pd


# generate test dataset
test_data = create_new_data(2000)
test_data.to_csv("data/test_data.csv", index=False)


# test models
x_train, x_test, y_train, y_test = read_data('data/test_data.csv')

accuracy_lr, accuracy_svm, accuracy_rf = model_select(x_train, y_train, x_test, y_test)

accuracy_nn, pred_label, pred_proba = nn_train_test(x_train, y_train, x_test, y_test)

print("lr accuracy is: ", accuracy_lr)
print("svm accuracy is: ", accuracy_svm)
print("rf accuracy is: ", accuracy_rf)
print("nn accuracy is", accuracy_nn)
