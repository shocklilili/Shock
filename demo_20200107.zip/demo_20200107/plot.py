import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

data = pd.read_csv('data/rf_result.csv')

plt.figure(figsize=[12, 10])
plt.scatter(data['size'], data['accuracy'], marker='o')
plt.plot(data['size'], data['accuracy'])
plt.xlabel('data size', size=16)
plt.ylabel('accuracy', size=16)
plt.title('The accuracy of RandonForest against the size of train data', size=20)
plt.savefig('data/rf_plot.png')
plt.show()