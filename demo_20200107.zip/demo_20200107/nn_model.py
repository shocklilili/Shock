import numpy as np
import pandas as pd
np.random.seed(123)  
from keras.models import Sequential 
from keras.layers import Dense, Activation
from load_data import read_data

def nn_model():
    model = Sequential() 
    # 2层隐藏层的浅层神经网络
    model.add(Dense(units=16, activation='relu', input_dim=4))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=16, activation='relu'))
    model.add(Dense(units=1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

def nn_train_test(x_train, y_train, x_test, y_test):
    # train the nn model
    print('nn Training ------------')
    model = nn_model()
    model.fit(x_train, y_train, epochs=5, batch_size=10)
    # evaluate the nn model
    print('\nnn Testing ------------')
    loss, accuracy = model.evaluate(x_test, y_test)
    pred_label = model.predict_classes(x_test, batch_size=10)
    pred_proba = model.predict_proba(x_test, batch_size=10)

    return accuracy, pred_label, pred_proba

