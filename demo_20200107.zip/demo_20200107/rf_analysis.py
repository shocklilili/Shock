
from create_data import create_new_data
from load_data import read_data, x_y_split
from ml_model import model_select, rf_model

import numpy as np
np.random.seed(123)  
import pandas as pd

test = pd.read_csv("data/test_data.csv")
x_test, y_test = x_y_split(test)

rf_result = dict()
for num in range(10, 15000, 500):
    temp_list = list()
    for times in range(50):
        train = create_new_data(num)
        x_train, y_train = x_y_split(train)
        pred_rf, accuracy_rf = rf_model(x_train, y_train, x_test, y_test)
        temp_list.append(accuracy_rf)
    temp_mean = np.mean(temp_list)
    rf_result[num] = temp_mean
    print(f'{num} : {temp_mean}', '\r')

rf_result_df = pd.DataFrame([rf_result.keys(), rf_result.values()]).T
rf_result_df.columns = ['size', 'accuracy']
print(rf_result_df.head())

rf_result_df.to_csv('data/rf_result.csv', index=False)
