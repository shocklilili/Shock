import pandas as pd
import csv
from numpy import *
import numpy as np
from dataloader import read_data, gradAscent, plotBestFit

if __name__ == '__main__':
    dataArr, labelMat = read_data()
    # 计算参数
    weights = gradAscent(dataArr, labelMat)
    print(weights)
    print(np.array([3, 4, 5, 6]).dot(weights))
    # plotBestFit(weights.getA())
