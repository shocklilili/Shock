import numpy as np
from pandas import DataFrame

mount = 10000   # amount of sample
rand_nps = []

for k in range(mount):
    # create matrix container
    arr = [0] * 5
    rand_np = np.random.randint(-100, 100, (2, 2))
    for i in range(2):
        for j in range(2):
            print("i = {} and j={}".format(i, j))
            index = i * 2 + j
            print(index)
            arr[index] = rand_np[i][j]
    eigenvl, _ = np.linalg.eig(rand_np)
    s = 0
    #data1 = DataFrame(rand_np)
    #data1.to_csv('train.csv')
    for e in eigenvl:
        if e > 0:
            s += 1
    arr[-1] = 1 if s > 0 else 0
    # arr = arr.reshape(1, -1)
    print(arr)
    rand_nps.append(arr)
# nps = np.array(rand_nps)
# rand_nps = np.arange(mount * 6).reshape(2, 3, mount)

nps = np.array(rand_nps).reshape(mount, -1)
print(nps)
data1 = DataFrame(nps)
data1.to_csv('train.csv')

